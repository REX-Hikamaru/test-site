// 家具のお手伝い - JavaScript機能

// ページ管理
let currentPage = 'home';

// ページ切り替え
function showPage(pageId) {
    // 全ページを非表示
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));
    
    // 指定ページを表示
    const targetPage = document.getElementById(pageId + '-page');
    if (targetPage) {
        targetPage.classList.add('active');
    }
    
    // ナビゲーションボタンの状態更新
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(btn => btn.classList.remove('active'));
    
    // アクティブボタンを設定
    const activeButton = Array.from(navButtons).find(btn => {
        const text = btn.textContent.trim();
        if (pageId === 'home' && text === 'ホーム') return true;
        if (pageId === 'about' && text === '会社概要・お問い合わせ') return true;
        if (pageId === 'game' && text === 'ミニゲーム') return true;
        return false;
    });
    
    if (activeButton) {
        activeButton.classList.add('active');
    }
    
    currentPage = pageId;
    
    // ページ切り替え時に特定の処理を実行
    if (pageId === 'game') {
        initializeGames();
    }
}

// ゲーム管理
let currentGame = 'breathing';
let breathingInterval = null;
let breathingActive = false;
let breathingCount = 0;
let breathingPhase = 'inhale';

// 記憶ゲーム
let memoryCards = [];
let memoryFlippedCards = [];
let memoryScore = 0;
let memoryGameStarted = false;

// 数字パズル
let puzzleNumbers = [];
let puzzleCurrentNumber = 1;
let puzzleStartTime = 0;
let puzzleGameStarted = false;

// ゲーム切り替え
function showGame(gameId) {
    // 全ゲームを非表示
    const games = document.querySelectorAll('.game-content');
    games.forEach(game => game.classList.remove('active'));
    
    // 指定ゲームを表示
    const targetGame = document.getElementById(gameId + '-game');
    if (targetGame) {
        targetGame.classList.add('active');
    }
    
    // タブの状態更新
    const tabs = document.querySelectorAll('.game-tab');
    tabs.forEach(tab => tab.classList.remove('active'));
    
    const activeTab = Array.from(tabs).find(tab => {
        const text = tab.textContent.trim();
        if (gameId === 'breathing' && text === '深呼吸タイム') return true;
        if (gameId === 'memory' && text === '記憶ゲーム') return true;
        if (gameId === 'puzzle' && text === '数字パズル') return true;
        return false;
    });
    
    if (activeTab) {
        activeTab.classList.add('active');
    }
    
    currentGame = gameId;
    
    // 前のゲームをリセット
    resetAllGames();
}

// 全ゲームリセット
function resetAllGames() {
    // 深呼吸ゲームリセット
    if (breathingInterval) {
        clearInterval(breathingInterval);
        breathingInterval = null;
    }
    breathingActive = false;
    breathingCount = 0;
    breathingPhase = 'inhale';
    
    const breathingBtn = document.getElementById('breathing-btn');
    const breathingText = document.getElementById('breathing-text');
    const breathingCircle = document.getElementById('breathing-circle');
    const breathingCountEl = document.getElementById('breathing-count');
    
    if (breathingBtn) breathingBtn.textContent = '深呼吸を始める';
    if (breathingText) breathingText.textContent = '準備はいいですか？';
    if (breathingCircle) {
        breathingCircle.className = 'breathing-circle';
    }
    if (breathingCountEl) breathingCountEl.textContent = '12';
}

// ゲーム初期化
function initializeGames() {
    resetAllGames();
}

// 深呼吸ゲーム
function toggleBreathing() {
    const btn = document.getElementById('breathing-btn');
    const text = document.getElementById('breathing-text');
    const circle = document.getElementById('breathing-circle');
    const countEl = document.getElementById('breathing-count');
    
    if (!breathingActive) {
        // 開始
        breathingActive = true;
        btn.textContent = '停止';
        breathingCount = 0;
        
        breathingInterval = setInterval(() => {
            breathingCount++;
            const displayCount = breathingCount % 12 || 12;
            countEl.textContent = displayCount;
            
            if (breathingCount <= 4) {
                breathingPhase = 'inhale';
                text.textContent = 'ゆっくり息を吸って...';
                circle.className = 'breathing-circle inhale';
            } else if (breathingCount <= 8) {
                breathingPhase = 'hold';
                text.textContent = '息を止めて...';
                circle.className = 'breathing-circle';
            } else if (breathingCount <= 12) {
                breathingPhase = 'exhale';
                text.textContent = 'ゆっくり息を吐いて...';
                circle.className = 'breathing-circle exhale';
            } else {
                breathingCount = 0;
            }
        }, 1000);
    } else {
        // 停止
        breathingActive = false;
        btn.textContent = '深呼吸を始める';
        text.textContent = '準備はいいですか？';
        circle.className = 'breathing-circle';
        countEl.textContent = '12';
        
        if (breathingInterval) {
            clearInterval(breathingInterval);
            breathingInterval = null;
        }
    }
}

// 記憶ゲーム開始
function startMemoryGame() {
    const emojis = ['🏠', '🪑', '🛏️', '🚪', '🪟', '🛋️', '📚', '🕯️'];
    const gameCards = [...emojis, ...emojis];
    
    // カードをシャッフル
    for (let i = gameCards.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [gameCards[i], gameCards[j]] = [gameCards[j], gameCards[i]];
    }
    
    // カード配列を初期化
    memoryCards = gameCards.map((emoji, index) => ({
        id: index,
        emoji: emoji,
        isFlipped: false,
        isMatched: false
    }));
    
    memoryFlippedCards = [];
    memoryScore = 0;
    memoryGameStarted = true;
    
    // UIを更新
    updateMemoryUI();
    document.getElementById('memory-score').textContent = memoryScore;
}

// 記憶ゲームUI更新
function updateMemoryUI() {
    const grid = document.getElementById('memory-grid');
    grid.innerHTML = '';
    
    memoryCards.forEach(card => {
        const cardEl = document.createElement('button');
        cardEl.className = 'memory-card';
        cardEl.textContent = (card.isFlipped || card.isMatched) ? card.emoji : '?';
        cardEl.onclick = () => handleMemoryCardClick(card.id);
        grid.appendChild(cardEl);
    });
}

// 記憶ゲームカードクリック
function handleMemoryCardClick(cardId) {
    if (memoryFlippedCards.length === 2) return;
    if (memoryCards[cardId].isFlipped || memoryCards[cardId].isMatched) return;
    
    // カードをめくる
    memoryCards[cardId].isFlipped = true;
    memoryFlippedCards.push(cardId);
    updateMemoryUI();
    
    if (memoryFlippedCards.length === 2) {
        setTimeout(() => {
            const [first, second] = memoryFlippedCards;
            
            if (memoryCards[first].emoji === memoryCards[second].emoji) {
                // マッチした場合
                memoryCards[first].isMatched = true;
                memoryCards[second].isMatched = true;
                memoryScore += 10;
                document.getElementById('memory-score').textContent = memoryScore;
                
                // 全てマッチしたかチェック
                if (memoryCards.every(card => card.isMatched)) {
                    setTimeout(() => {
                        alert('🎉 おめでとうございます！完成です！ 🎉');
                    }, 500);
                }
            } else {
                // マッチしなかった場合
                memoryCards[first].isFlipped = false;
                memoryCards[second].isFlipped = false;
            }
            
            memoryFlippedCards = [];
            updateMemoryUI();
        }, 1000);
    }
}

// 数字パズル開始
function startPuzzleGame() {
    // 1-9の数字をシャッフル
    puzzleNumbers = Array.from({length: 9}, (_, i) => i + 1);
    for (let i = puzzleNumbers.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [puzzleNumbers[i], puzzleNumbers[j]] = [puzzleNumbers[j], puzzleNumbers[i]];
    }
    
    puzzleCurrentNumber = 1;
    puzzleStartTime = Date.now();
    puzzleGameStarted = true;
    
    updatePuzzleUI();
    document.getElementById('current-number').textContent = puzzleCurrentNumber;
    
    // タイマー開始
    const timer = setInterval(() => {
        if (puzzleCurrentNumber > 9) {
            clearInterval(timer);
            return;
        }
        
        const elapsed = ((Date.now() - puzzleStartTime) / 1000).toFixed(1);
        document.getElementById('game-time').textContent = elapsed;
    }, 100);
}

// 数字パズルUI更新
function updatePuzzleUI() {
    const grid = document.getElementById('puzzle-grid');
    grid.innerHTML = '';
    
    puzzleNumbers.forEach(number => {
        const numberEl = document.createElement('button');
        numberEl.className = 'puzzle-number';
        numberEl.textContent = number;
        
        if (number < puzzleCurrentNumber) {
            numberEl.classList.add('completed');
        } else if (number === puzzleCurrentNumber) {
            numberEl.classList.add('current');
        }
        
        numberEl.onclick = () => handlePuzzleNumberClick(number);
        grid.appendChild(numberEl);
    });
}

// 数字パズル番号クリック
function handlePuzzleNumberClick(number) {
    if (number === puzzleCurrentNumber) {
        puzzleCurrentNumber++;
        
        if (puzzleCurrentNumber > 9) {
            // ゲーム完了
            const endTime = Date.now();
            const gameTime = ((endTime - puzzleStartTime) / 1000).toFixed(1);
            document.getElementById('current-number').textContent = '完成！';
            setTimeout(() => {
                alert(`🎉 ${gameTime}秒でクリア！ 🎉`);
            }, 500);
        } else {
            document.getElementById('current-number').textContent = puzzleCurrentNumber;
        }
        
        updatePuzzleUI();
    }
}

// フォーム処理
function handleFormSubmit(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    const name = formData.get('name');
    const phone = formData.get('phone');
    
    if (!name || !phone) {
        alert('お名前とお電話番号は必須です');
        return;
    }
    
    // 送信処理（実際のプロジェクトではPHPに送信）
    // ここではダミーの処理
    setTimeout(() => {
        alert('お問い合わせありがとうございます。2営業日以内にご連絡いたします。');
        form.reset();
    }, 500);
}

// トースト通知（簡易版）
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : '#ef4444'};
        color: white;
        padding: 1rem 2rem;
        border-radius: 0.5rem;
        font-weight: 600;
        z-index: 1000;
        box-shadow: 0 10px 15px rgba(0,0,0,0.1);
        animation: slideIn 0.3s ease-out;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}

// CSS アニメーション追加
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// ページ読み込み時の初期化
document.addEventListener('DOMContentLoaded', function() {
    // 初期ページ設定
    showPage('home');
    
    // フォーム送信イベント
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', handleFormSubmit);
    }
    
    // スムーズスクロール
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // レスポンシブ対応
    function handleResize() {
        if (window.innerWidth <= 768) {
            // モバイル用の調整
        }
    }
    
    window.addEventListener('resize', handleResize);
    handleResize();
});

// ユーティリティ関数
function formatPhoneNumber(phone) {
    // 電話番号のフォーマット
    return phone.replace(/[^\d-]/g, '');
}

function validateEmail(email) {
    // メールアドレスの検証
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// ローカルストレージを使用した設定保存
function saveUserPreference(key, value) {
    try {
        localStorage.setItem('kagu_' + key, JSON.stringify(value));
    } catch (e) {
        console.log('ローカルストレージに保存できません');
    }
}

function getUserPreference(key, defaultValue = null) {
    try {
        const stored = localStorage.getItem('kagu_' + key);
        return stored ? JSON.parse(stored) : defaultValue;
    } catch (e) {
        return defaultValue;
    }
}

// ゲームスコア保存
function saveGameScore(game, score) {
    const scores = getUserPreference('game_scores', {});
    scores[game] = Math.max(scores[game] || 0, score);
    saveUserPreference('game_scores', scores);
}

function getGameScore(game) {
    const scores = getUserPreference('game_scores', {});
    return scores[game] || 0;
}

// エラーハンドリング
window.addEventListener('error', function(e) {
    console.error('エラーが発生しました:', e.error);
    // 本番環境では詳細なエラーログを送信
});

// パフォーマンス最適化
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 画像遅延読み込み
function lazyLoadImages() {
    const images = document.querySelectorAll('img[data-src]');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        images.forEach(img => imageObserver.observe(img));
    } else {
        // フォールバック
        images.forEach(img => {
            img.src = img.dataset.src;
        });
    }
}

// アクセシビリティ改善
function improveAccessibility() {
    // キーボードナビゲーション
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
            document.body.classList.add('keyboard-nav');
        }
    });
    
    document.addEventListener('mousedown', function() {
        document.body.classList.remove('keyboard-nav');
    });
    
    // フォーカス管理
    const focusableElements = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            // モーダルやポップアップを閉じる処理
            const activeModal = document.querySelector('.modal.active');
            if (activeModal) {
                closeModal(activeModal);
            }
        }
    });
}

// 初期化実行
document.addEventListener('DOMContentLoaded', function() {
    improveAccessibility();
    lazyLoadImages();
});

// アクセシビリティ用CSS追加
const accessibilityStyle = document.createElement('style');
accessibilityStyle.textContent = `
    .keyboard-nav *:focus {
        outline: 2px solid var(--emerald-600);
        outline-offset: 2px;
    }
    
    @media (prefers-reduced-motion: reduce) {
        *, *::before, *::after {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
        }
    }
    
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0;
    }
`;
document.head.appendChild(accessibilityStyle);