<?php
// 家具のお手伝い - お問い合わせフォーム処理

// セキュリティヘッダー
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

// エラー報告設定
error_reporting(E_ALL);
ini_set('display_errors', 0); // 本番環境では0に設定

// セッション開始（CSRF対策用）
session_start();

// 設定
$config = [
    'admin_email' => 'info@kagu-otetsudai.jp',
    'site_name' => '家具のお手伝い',
    'max_message_length' => 2000,
    'allowed_categories' => ['living', 'kitchen', 'children', 'delivery', 'other']
];

// レスポンス用の配列
$response = [
    'success' => false,
    'message' => '',
    'errors' => []
];

// CSRFトークン生成
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// CSRFトークン検証
function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// 入力データのサニタイズ
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

// メールアドレス検証
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// 電話番号検証（日本の電話番号形式）
function validatePhoneNumber($phone) {
    $phone = preg_replace('/[^0-9\-]/', '', $phone);
    // 日本の電話番号パターン
    $patterns = [
        '/^0\d{1,4}-\d{1,4}-\d{3,4}$/', // ハイフン付き
        '/^0\d{9,10}$/', // ハイフンなし
        '/^0120-\d{3}-\d{3}$/' // フリーダイヤル
    ];
    
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $phone)) {
            return true;
        }
    }
    return false;
}

// スパム検証（簡易版）
function isSpam($data) {
    $spam_words = ['spam', 'casino', 'loan', 'viagra', 'cialis'];
    $content = strtolower($data['name'] . ' ' . $data['message']);
    
    foreach ($spam_words as $word) {
        if (strpos($content, $word) !== false) {
            return true;
        }
    }
    
    // 同じIPからの連続送信チェック
    if (isset($_SESSION['last_submit_time']) && 
        (time() - $_SESSION['last_submit_time']) < 60) { // 1分以内
        return true;
    }
    
    return false;
}

// メール送信
function sendEmail($to, $subject, $message, $headers) {
    // 本番環境では実際のメール送信ライブラリを使用
    // 例: PHPMailer, SwiftMailer など
    
    // デバッグ用（開発環境）
    if (defined('DEBUG') && DEBUG) {
        error_log("メール送信: TO: $to, SUBJECT: $subject");
        error_log("MESSAGE: $message");
        return true;
    }
    
    // 実際のメール送信
    return mail($to, $subject, $message, $headers);
}

// ログ出力
function logMessage($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] [$level] $message" . PHP_EOL;
    file_put_contents('logs/contact.log', $log_entry, FILE_APPEND | LOCK_EX);
}

try {
    // POSTリクエストのみ処理
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('不正なリクエストです。');
    }
    
    // CSRF トークン検証（実装時は有効化）
    // if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
    //     throw new Exception('セキュリティトークンが無効です。');
    // }
    
    // 入力データ取得とサニタイズ
    $name = sanitizeInput($_POST['name'] ?? '');
    $phone = sanitizeInput($_POST['phone'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $category = sanitizeInput($_POST['category'] ?? '');
    $message = sanitizeInput($_POST['message'] ?? '');
    
    // バリデーション
    if (empty($name)) {
        $response['errors'][] = 'お名前を入力してください。';
    } elseif (strlen($name) > 50) {
        $response['errors'][] = 'お名前は50文字以内で入力してください。';
    }
    
    if (empty($phone)) {
        $response['errors'][] = 'お電話番号を入力してください。';
    } elseif (!validatePhoneNumber($phone)) {
        $response['errors'][] = '正しい電話番号を入力してください。';
    }
    
    if (!empty($email) && !validateEmail($email)) {
        $response['errors'][] = '正しいメールアドレスを入力してください。';
    }
    
    if (!empty($category) && !in_array($category, $config['allowed_categories'])) {
        $response['errors'][] = '不正なカテゴリが選択されています。';
    }
    
    if (strlen($message) > $config['max_message_length']) {
        $response['errors'][] = 'メッセージは2000文字以内で入力してください。';
    }
    
    // エラーがある場合は処理を中断
    if (!empty($response['errors'])) {
        throw new Exception('入力内容にエラーがあります。');
    }
    
    // スパムチェック
    $form_data = compact('name', 'phone', 'email', 'category', 'message');
    if (isSpam($form_data)) {
        logMessage("スパム検知: " . json_encode($form_data), 'WARNING');
        // スパムの場合も成功レスポンスを返す（攻撃者に気づかれないため）
        $response['success'] = true;
        $response['message'] = 'お問い合わせありがとうございます。2営業日以内にご連絡いたします。';
    } else {
        // カテゴリ名の日本語化
        $category_names = [
            'living' => 'リビング家具について',
            'kitchen' => 'キッチン収納について',
            'children' => '子ども部屋家具について',
            'delivery' => '配送・設置について',
            'other' => 'その他'
        ];
        $category_display = $category_names[$category] ?? 'その他';
        
        // 管理者宛メール作成
        $admin_subject = '【' . $config['site_name'] . '】新しいお問い合わせ';
        $admin_message = "新しいお問い合わせが届きました。\n\n";
        $admin_message .= "■ お名前: " . $name . "\n";
        $admin_message .= "■ 電話番号: " . $phone . "\n";
        $admin_message .= "■ メールアドレス: " . ($email ?: '未入力') . "\n";
        $admin_message .= "■ お問い合わせ内容: " . $category_display . "\n";
        $admin_message .= "■ 詳細: \n" . ($message ?: '未入力') . "\n\n";
        $admin_message .= "■ 送信日時: " . date('Y年n月j日 G:i') . "\n";
        $admin_message .= "■ IPアドレス: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . "\n";
        
        $admin_headers = "From: noreply@kagu-otetsudai.jp\r\n";
        $admin_headers .= "Reply-To: noreply@kagu-otetsudai.jp\r\n";
        $admin_headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        
        // 顧客宛自動返信メール（メールアドレスがある場合のみ）
        if (!empty($email)) {
            $customer_subject = '【' . $config['site_name'] . '】お問い合わせありがとうございます';
            $customer_message = $name . " 様\n\n";
            $customer_message .= "この度は「" . $config['site_name'] . "」にお問い合わせいただき、誠にありがとうございます。\n\n";
            $customer_message .= "以下の内容でお問い合わせを承りました。\n";
            $customer_message .= "2営業日以内に担当者よりご連絡させていただきます。\n\n";
            $customer_message .= "■ お問い合わせ内容: " . $category_display . "\n";
            if ($message) {
                $customer_message .= "■ 詳細: \n" . $message . "\n";
            }
            $customer_message .= "\n";
            $customer_message .= "【お急ぎの場合は】\n";
            $customer_message .= "お電話でもお問い合わせを承っております。\n";
            $customer_message .= "TEL: 0120-123-456\n";
            $customer_message .= "受付時間: 平日 9:00-18:00 / 土曜 10:00-16:00\n\n";
            $customer_message .= "毎日の家事、本当にお疲れ様です。\n";
            $customer_message .= "私たちがしっかりとサポートさせていただきます。\n\n";
            $customer_message .= "─────────────────────────────────────\n";
            $customer_message .= "株式会社 家具のお手伝い\n";
            $customer_message .= "〒154-0014 東京都世田谷区桜新町1-2-3 桜ビル4F\n";
            $customer_message .= "TEL: 0120-123-456\n";
            $customer_message .= "Email: info@kagu-otetsudai.jp\n";
            $customer_message .= "─────────────────────────────────────\n";
            
            $customer_headers = "From: " . $config['admin_email'] . "\r\n";
            $customer_headers .= "Reply-To: " . $config['admin_email'] . "\r\n";
            $customer_headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        }
        
        // メール送信実行
        $admin_sent = sendEmail($config['admin_email'], $admin_subject, $admin_message, $admin_headers);
        
        if (!$admin_sent) {
            logMessage("管理者メール送信失敗: $name, $phone", 'ERROR');
            throw new Exception('申し訳ございません。システムエラーが発生しました。お電話でお問い合わせください。');
        }
        
        // 顧客宛自動返信メール送信（オプション）
        if (!empty($email)) {
            $customer_sent = sendEmail($email, $customer_subject, $customer_message, $customer_headers);
            if (!$customer_sent) {
                logMessage("顧客メール送信失敗: $email", 'WARNING');
                // 自動返信メール失敗は処理を止めない
            }
        }
        
        // 正常処理完了
        $_SESSION['last_submit_time'] = time();
        
        logMessage("問い合わせ受信: $name ($phone)", 'INFO');
        
        $response['success'] = true;
        $response['message'] = 'お問い合わせありがとうございます。2営業日以内にご連絡いたします。';
    }

} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
    
    // エラーログ出力
    logMessage("エラー: " . $e->getMessage(), 'ERROR');
    
    // 一般的なエラーメッセージに変更（セキュリティ上の理由）
    if (empty($response['errors'])) {
        $response['message'] = '申し訳ございません。一時的にシステムエラーが発生しています。お電話でお問い合わせください。';
    }
}

// レスポンス出力
header('Content-Type: application/json; charset=UTF-8');

// AJAXリクエストの場合はJSONで返す
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
    strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
} else {
    // 通常のフォーム送信の場合はリダイレクト
    if ($response['success']) {
        // 成功時
        header('Location: index.html?success=1');
    } else {
        // エラー時
        $error_msg = urlencode($response['message']);
        header('Location: index.html?error=' . $error_msg);
    }
}
exit;

// CSRFトークン生成用のヘルパー関数（フォームで使用）
function getCSRFTokenField() {
    $token = generateCSRFToken();
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token) . '">';
}
?>