import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { useState } from "react";
import { toast } from "sonner@2.0.3";

export default function AboutPage() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    category: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) {
      toast.error("お名前とお電話番号は必須です");
      return;
    }
    toast.success("お問い合わせありがとうございます。2営業日以内にご連絡いたします。");
    setFormData({ name: "", phone: "", email: "", category: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-blue-50 py-8 px-4">
      <div className="container mx-auto max-w-4xl">
        
        {/* 会社概要 */}
        <Card className="mb-8 shadow-lg border-2 border-slate-200">
          <CardHeader className="bg-gradient-to-r from-emerald-600 to-blue-600 text-white">
            <CardTitle className="text-3xl">会社概要</CardTitle>
            <CardDescription className="text-emerald-100 text-lg">
              家具のお手伝いについて
            </CardDescription>
          </CardHeader>
          <CardContent className="p-8">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-2xl font-bold text-slate-800 mb-4">私たちの想い</h3>
                <p className="text-lg text-slate-600 leading-relaxed mb-6">
                  毎日家事や育児でお忙しい親御さんの負担を、少しでも軽くしたい。
                  そんな想いから「家具のお手伝い」は生まれました。
                </p>
                <p className="text-lg text-slate-600 leading-relaxed">
                  掃除しやすい、片付けやすい、安全で使いやすい家具をご提案することで、
                  ご家族がもっと笑顔で過ごせる時間を作るお手伝いをします。
                </p>
              </div>
              <div className="space-y-4">
                <div>
                  <h4 className="text-xl font-bold text-slate-800">会社名</h4>
                  <p className="text-lg text-slate-600">株式会社 家具のお手伝い</p>
                </div>
                <div>
                  <h4 className="text-xl font-bold text-slate-800">設立</h4>
                  <p className="text-lg text-slate-600">2020年4月</p>
                </div>
                <div>
                  <h4 className="text-xl font-bold text-slate-800">代表</h4>
                  <p className="text-lg text-slate-600">田中 幸子</p>
                </div>
                <div>
                  <h4 className="text-xl font-bold text-slate-800">従業員数</h4>
                  <p className="text-lg text-slate-600">35名</p>
                </div>
                <div>
                  <h4 className="text-xl font-bold text-slate-800">所在地</h4>
                  <p className="text-lg text-slate-600">東京都世田谷区桜新町1-2-3<br />桜ビル4F</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* サービス内容 */}
        <Card className="mb-8 shadow-lg border-2 border-slate-200">
          <CardHeader>
            <CardTitle className="text-2xl text-slate-800">サービス内容</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="border-emerald-200">
                <CardHeader>
                  <CardTitle className="text-xl text-emerald-600">家具選びのご相談</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-slate-600">
                    <li>• ライフスタイルに合った家具のご提案</li>
                    <li>• お部屋の間取りに合わせたレイアウト</li>
                    <li>• 予算に応じた商品選び</li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-blue-200">
                <CardHeader>
                  <CardTitle className="text-xl text-blue-600">配送・設置サービス</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-slate-600">
                    <li>• ご自宅までの安全配送</li>
                    <li>• 組み立て・設置作業</li>
                    <li>• 不要家具の引き取り</li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-teal-200">
                <CardHeader>
                  <CardTitle className="text-xl text-teal-600">アフターサポート</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-slate-600">
                    <li>• 購入後のご相談対応</li>
                    <li>• メンテナンスサービス</li>
                    <li>• 買い替え時のご提案</li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-slate-300">
                <CardHeader>
                  <CardTitle className="text-xl text-slate-600">お電話サポート</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-slate-600">
                    <li>• ネットが苦手な方もお電話で</li>
                    <li>• 平日9:00-18:00対応</li>
                    <li>• 土曜日も10:00-16:00対応</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>

        {/* お問い合わせフォーム */}
        <Card className="shadow-lg border-2 border-emerald-200">
          <CardHeader className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white">
            <CardTitle className="text-3xl">お問い合わせ</CardTitle>
            <CardDescription className="text-emerald-100 text-lg">
              お気軽にご相談ください。お電話でも承ります。
            </CardDescription>
          </CardHeader>
          <CardContent className="p-8">
            
            {/* 電話番号案内 */}
            <div className="mb-8 p-6 bg-emerald-50 rounded-lg border-2 border-emerald-200">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-emerald-600 rounded-full flex items-center justify-center">
                  <span className="text-2xl">📞</span>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-emerald-700">お電話でのお問い合わせ</h3>
                  <p className="text-3xl font-bold text-emerald-800">0120-123-456</p>
                  <p className="text-slate-600">平日 9:00-18:00 / 土曜 10:00-16:00</p>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="name" className="text-lg">お名前 <span className="text-red-500">*</span></Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="田中 花子"
                    className="text-lg p-3 border-2"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="phone" className="text-lg">お電話番号 <span className="text-red-500">*</span></Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    placeholder="03-1234-5678"
                    className="text-lg p-3 border-2"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="email" className="text-lg">メールアドレス（任意）</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  placeholder="example@email.com"
                  className="text-lg p-3 border-2"
                />
              </div>

              <div>
                <Label htmlFor="category" className="text-lg">お問い合わせ内容</Label>
                <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                  <SelectTrigger className="text-lg p-3 border-2">
                    <SelectValue placeholder="選択してください" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="living">リビング家具について</SelectItem>
                    <SelectItem value="kitchen">キッチン収納について</SelectItem>
                    <SelectItem value="children">子ども部屋家具について</SelectItem>
                    <SelectItem value="delivery">配送・設置について</SelectItem>
                    <SelectItem value="other">その他</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="message" className="text-lg">詳しいご相談内容</Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  placeholder="どのようなことでお困りですか？お気軽にお聞かせください。"
                  className="text-lg p-3 border-2 h-32"
                />
              </div>

              <div className="text-center pt-4">
                <Button 
                  type="submit"
                  className="text-xl px-12 py-4 bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  送信する
                </Button>
              </div>
            </form>

            <div className="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-slate-600 text-center">
                ※ いただいたお問い合わせには、2営業日以内にご返答いたします。<br />
                お急ぎの場合は、お電話でお問い合わせください。
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}