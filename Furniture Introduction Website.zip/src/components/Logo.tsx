export default function Logo({ className = "w-12 h-12" }: { className?: string }) {
  return (
    <div className={`${className} relative`}>
      <svg viewBox="0 0 100 100" className="w-full h-full">
        {/* 背景円 */}
        <circle 
          cx="50" 
          cy="50" 
          r="48" 
          fill="url(#logoGradient)" 
          stroke="#1e293b" 
          strokeWidth="2"
        />
        
        {/* 家のシルエット */}
        <g transform="translate(25, 30)">
          {/* 屋根 */}
          <path 
            d="M25 15 L10 25 L40 25 Z" 
            fill="#ffffff" 
            stroke="#065f46" 
            strokeWidth="1.5"
          />
          {/* 家の本体 */}
          <rect 
            x="12" 
            y="25" 
            width="26" 
            height="20" 
            fill="#ffffff" 
            stroke="#065f46" 
            strokeWidth="1.5"
          />
          {/* ドア */}
          <rect 
            x="20" 
            y="35" 
            width="6" 
            height="10" 
            fill="#059669" 
            stroke="#065f46" 
            strokeWidth="1"
          />
          {/* ドアノブ */}
          <circle 
            cx="24" 
            cy="40" 
            r="1" 
            fill="#065f46"
          />
          {/* 窓 */}
          <rect 
            x="30" 
            y="30" 
            width="5" 
            height="5" 
            fill="#0891b2" 
            stroke="#065f46" 
            strokeWidth="1"
          />
          {/* 窓の十字 */}
          <line 
            x1="32.5" 
            y1="30" 
            x2="32.5" 
            y2="35" 
            stroke="#ffffff" 
            strokeWidth="0.5"
          />
          <line 
            x1="30" 
            y1="32.5" 
            x2="35" 
            y2="32.5" 
            stroke="#ffffff" 
            strokeWidth="0.5"
          />
        </g>
        
        {/* ハート（家族の愛を表現） */}
        <g transform="translate(65, 25)">
          <path 
            d="M12 8 C12 5, 9 3, 6 5 C3 3, 0 5, 0 8 C0 12, 6 18, 6 18 C6 18, 12 12, 12 8 Z" 
            fill="#ef4444" 
            opacity="0.8"
          />
        </g>
        
        {/* グラデーション定義 */}
        <defs>
          <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="50%" stopColor="#059669" />
            <stop offset="100%" stopColor="#047857" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}