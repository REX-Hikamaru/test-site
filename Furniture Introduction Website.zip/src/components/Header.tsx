import { Button } from "./ui/button";
import Logo from "./Logo";

interface HeaderProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

export default function Header({ currentPage, onPageChange }: HeaderProps) {
  return (
    <header className="bg-slate-800 text-white shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Logo className="w-14 h-14" />
            <div>
              <h1 className="text-2xl font-bold text-emerald-400">家具のお手伝い</h1>
              <p className="text-sm text-slate-300">あなたの家事をサポートする家具</p>
            </div>
          </div>
          
          <nav className="flex space-x-2">
            <Button
              variant={currentPage === "home" ? "secondary" : "ghost"}
              onClick={() => onPageChange("home")}
              className="text-lg px-6 py-3 bg-emerald-600 hover:bg-emerald-500"
            >
              ホーム
            </Button>
            <Button
              variant={currentPage === "about" ? "secondary" : "ghost"}
              onClick={() => onPageChange("about")}
              className="text-lg px-6 py-3 bg-blue-600 hover:bg-blue-500"
            >
              会社概要・お問い合わせ
            </Button>
            <Button
              variant={currentPage === "game" ? "secondary" : "ghost"}
              onClick={() => onPageChange("game")}
              className="text-lg px-6 py-3 bg-teal-600 hover:bg-teal-500"
            >
              ミニゲーム
            </Button>
          </nav>
        </div>
      </div>
    </header>
  );
}