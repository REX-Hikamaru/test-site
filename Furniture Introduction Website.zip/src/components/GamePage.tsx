import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { useState, useEffect } from "react";

export default function GamePage() {
  const [currentGame, setCurrentGame] = useState<"memory" | "puzzle" | "breathing">("breathing");
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-50 to-emerald-50 py-8 px-4">
      <div className="container mx-auto max-w-4xl">
        
        <Card className="mb-8 shadow-lg border-2 border-teal-200">
          <CardHeader className="bg-gradient-to-r from-teal-600 to-emerald-600 text-white text-center">
            <CardTitle className="text-3xl">ちょっと息抜きタイム</CardTitle>
            <p className="text-teal-100 text-lg">
              毎日お疲れ様です。少しだけリラックスしませんか？
            </p>
          </CardHeader>
          <CardContent className="p-8">
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <Button
                onClick={() => setCurrentGame("breathing")}
                variant={currentGame === "breathing" ? "default" : "outline"}
                className="text-lg py-4 bg-teal-600 hover:bg-teal-700"
              >
                深呼吸タイム
              </Button>
              <Button
                onClick={() => setCurrentGame("memory")}
                variant={currentGame === "memory" ? "default" : "outline"}
                className="text-lg py-4 bg-emerald-600 hover:bg-emerald-700"
              >
                記憶ゲーム
              </Button>
              <Button
                onClick={() => setCurrentGame("puzzle")}
                variant={currentGame === "puzzle" ? "default" : "outline"}
                className="text-lg py-4 bg-blue-600 hover:bg-blue-700"
              >
                数字パズル
              </Button>
            </div>

            {currentGame === "breathing" && <BreathingGame />}
            {currentGame === "memory" && <MemoryGame />}
            {currentGame === "puzzle" && <NumberPuzzle />}
          </CardContent>
        </Card>

        <Card className="border-2 border-emerald-200 bg-emerald-50">
          <CardContent className="p-6 text-center">
            <h3 className="text-2xl font-bold text-emerald-700 mb-4">お疲れ様でした</h3>
            <p className="text-lg text-slate-600">
              少しでもリフレッシュできましたでしょうか？<br />
              家具のことでご不明点がございましたら、いつでもお気軽にお問い合わせください。
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function BreathingGame() {
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState<"inhale" | "hold" | "exhale">("inhale");
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isActive) return;

    const timer = setInterval(() => {
      setCount((prev) => {
        const newCount = prev + 1;
        if (newCount <= 4) {
          setPhase("inhale");
        } else if (newCount <= 8) {
          setPhase("hold");
        } else if (newCount <= 12) {
          setPhase("exhale");
        } else {
          return 0;
        }
        return newCount;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isActive]);

  const getPhaseText = () => {
    switch (phase) {
      case "inhale": return "ゆっくり息を吸って...";
      case "hold": return "息を止めて...";
      case "exhale": return "ゆっくり息を吐いて...";
    }
  };

  const getCircleSize = () => {
    switch (phase) {
      case "inhale": return "w-40 h-40";
      case "hold": return "w-40 h-40";
      case "exhale": return "w-20 h-20";
    }
  };

  return (
    <div className="text-center space-y-8">
      <h3 className="text-2xl font-bold text-teal-700">深呼吸でリラックス</h3>
      <p className="text-lg text-slate-600">
        4秒吸って、4秒止めて、4秒で吐く。これを繰り返しましょう。
      </p>
      
      <div className="flex flex-col items-center space-y-6">
        <div 
          className={`${getCircleSize()} bg-gradient-to-br from-teal-400 to-emerald-500 rounded-full transition-all duration-1000 flex items-center justify-center`}
        >
          <span className="text-white font-bold text-lg">{count % 12 || 12}</span>
        </div>
        
        <p className="text-2xl font-bold text-teal-700 h-8">
          {isActive ? getPhaseText() : "準備はいいですか？"}
        </p>
        
        <Button
          onClick={() => setIsActive(!isActive)}
          className="text-xl px-8 py-4 bg-teal-600 hover:bg-teal-700"
        >
          {isActive ? "停止" : "深呼吸を始める"}
        </Button>
      </div>
    </div>
  );
}

function MemoryGame() {
  const [cards, setCards] = useState<Array<{id: number, emoji: string, isFlipped: boolean, isMatched: boolean}>>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);

  const emojis = ["🏠", "🪑", "🛏️", "🚪", "🪟", "🛋️", "📚", "🕯️"];

  const initializeGame = () => {
    const gameCards = [...emojis, ...emojis]
      .map((emoji, index) => ({
        id: index,
        emoji,
        isFlipped: false,
        isMatched: false
      }))
      .sort(() => Math.random() - 0.5);
    
    setCards(gameCards);
    setFlippedCards([]);
    setScore(0);
    setGameStarted(true);
  };

  const handleCardClick = (cardId: number) => {
    if (flippedCards.length === 2) return;
    if (cards[cardId].isFlipped || cards[cardId].isMatched) return;

    const newCards = cards.map(card => 
      card.id === cardId ? { ...card, isFlipped: true } : card
    );
    setCards(newCards);

    const newFlippedCards = [...flippedCards, cardId];
    setFlippedCards(newFlippedCards);

    if (newFlippedCards.length === 2) {
      setTimeout(() => {
        const [first, second] = newFlippedCards;
        if (cards[first].emoji === cards[second].emoji) {
          setCards(prev => prev.map(card => 
            card.id === first || card.id === second 
              ? { ...card, isMatched: true } 
              : card
          ));
          setScore(prev => prev + 10);
        } else {
          setCards(prev => prev.map(card => 
            card.id === first || card.id === second 
              ? { ...card, isFlipped: false } 
              : card
          ));
        }
        setFlippedCards([]);
      }, 1000);
    }
  };

  const allMatched = cards.length > 0 && cards.every(card => card.isMatched);

  return (
    <div className="text-center space-y-8">
      <h3 className="text-2xl font-bold text-emerald-700">記憶力ゲーム</h3>
      <p className="text-lg text-slate-600">
        同じ絵柄のカードを見つけてペアにしましょう！
      </p>
      
      {!gameStarted ? (
        <Button
          onClick={initializeGame}
          className="text-xl px-8 py-4 bg-emerald-600 hover:bg-emerald-700"
        >
          ゲームスタート
        </Button>
      ) : (
        <>
          <div className="text-xl font-bold text-emerald-700">
            スコア: {score}点
          </div>
          
          {allMatched && (
            <div className="text-2xl font-bold text-emerald-600">
              🎉 おめでとうございます！完成です！ 🎉
            </div>
          )}
          
          <div className="grid grid-cols-4 gap-4 max-w-md mx-auto">
            {cards.map((card) => (
              <button
                key={card.id}
                onClick={() => handleCardClick(card.id)}
                className="w-16 h-16 bg-emerald-200 hover:bg-emerald-300 rounded-lg border-2 border-emerald-400 flex items-center justify-center text-2xl transition-colors"
              >
                {card.isFlipped || card.isMatched ? card.emoji : "?"}
              </button>
            ))}
          </div>
          
          <Button
            onClick={initializeGame}
            variant="outline"
            className="border-2 border-emerald-600 text-emerald-600 hover:bg-emerald-50"
          >
            新しいゲーム
          </Button>
        </>
      )}
    </div>
  );
}

function NumberPuzzle() {
  const [numbers, setNumbers] = useState<number[]>([]);
  const [currentNumber, setCurrentNumber] = useState(1);
  const [gameStarted, setGameStarted] = useState(false);
  const [startTime, setStartTime] = useState(0);
  const [endTime, setEndTime] = useState(0);

  const initializeGame = () => {
    const shuffled = Array.from({length: 9}, (_, i) => i + 1)
      .sort(() => Math.random() - 0.5);
    setNumbers(shuffled);
    setCurrentNumber(1);
    setGameStarted(true);
    setStartTime(Date.now());
    setEndTime(0);
  };

  const handleNumberClick = (number: number) => {
    if (number === currentNumber) {
      setCurrentNumber(prev => prev + 1);
      if (number === 9) {
        setEndTime(Date.now());
      }
    }
  };

  const isComplete = currentNumber > 9;
  const gameTime = endTime ? ((endTime - startTime) / 1000).toFixed(1) : "0";

  return (
    <div className="text-center space-y-8">
      <h3 className="text-2xl font-bold text-blue-700">数字パズル</h3>
      <p className="text-lg text-slate-600">
        1から9まで順番にタップしましょう！
      </p>
      
      {!gameStarted ? (
        <Button
          onClick={initializeGame}
          className="text-xl px-8 py-4 bg-blue-600 hover:bg-blue-700"
        >
          ゲームスタート
        </Button>
      ) : (
        <>
          <div className="text-xl font-bold text-blue-700">
            次の数字: {isComplete ? "完成！" : currentNumber}
          </div>
          
          {isComplete && (
            <div className="text-2xl font-bold text-blue-600">
              🎉 {gameTime}秒でクリア！ 🎉
            </div>
          )}
          
          <div className="grid grid-cols-3 gap-4 max-w-xs mx-auto">
            {numbers.map((number) => (
              <button
                key={number}
                onClick={() => handleNumberClick(number)}
                className={`w-16 h-16 rounded-lg border-2 flex items-center justify-center text-2xl font-bold transition-colors ${
                  number < currentNumber
                    ? "bg-green-200 border-green-400 text-green-800"
                    : number === currentNumber
                    ? "bg-blue-200 border-blue-400 text-blue-800 hover:bg-blue-300"
                    : "bg-slate-200 border-slate-400 text-slate-600 hover:bg-slate-300"
                }`}
                disabled={isComplete}
              >
                {number}
              </button>
            ))}
          </div>
          
          <Button
            onClick={initializeGame}
            variant="outline"
            className="border-2 border-blue-600 text-blue-600 hover:bg-blue-50"
          >
            新しいゲーム
          </Button>
        </>
      )}
    </div>
  );
}