import Logo from "./Logo";

export default function Footer() {
  return (
    <footer className="bg-slate-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <Logo className="w-12 h-12" />
              <h3 className="text-xl font-bold text-emerald-400">家具のお手伝い</h3>
            </div>
            <p className="text-slate-300 leading-relaxed">
              家事でお忙しい親御さんの負担を軽くする家具をご提案します。
              安心してご相談ください。
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-4 text-emerald-400">お問い合わせ</h4>
            <div className="space-y-2 text-slate-300">
              <div className="flex items-center space-x-2">
                <span>📞</span>
                <span>0120-123-456</span>
              </div>
              <div className="text-sm">平日 9:00-18:00 / 土曜 10:00-16:00</div>
              <div className="flex items-center space-x-2">
                <span>📧</span>
                <span>info@kagu-otetsudai.jp</span>
              </div>
              <div className="flex items-center space-x-2">
                <span>🏢</span>
                <span>東京都世田谷区桜新町1-2-3</span>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-4 text-emerald-400">サービス</h4>
            <ul className="space-y-2 text-slate-300">
              <li>• リビング家具のご提案</li>
              <li>• キッチン収納のご提案</li>
              <li>• 子ども部屋家具のご提案</li>
              <li>• 配送・設置サービス</li>
              <li>• アフターサポート</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-600 mt-8 pt-8 text-center">
          <p className="text-slate-400">
            &copy; 2024 株式会社 家具のお手伝い. All rights reserved.
          </p>
          <p className="text-slate-500 text-sm mt-2">
            毎日の家事、本当にお疲れ様です。私たちがサポートします。
          </p>
        </div>
      </div>
    </footer>
  );
}