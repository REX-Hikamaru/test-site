import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface HomePageProps {
  onPageChange: (page: string) => void;
}

export default function HomePage({ onPageChange }: HomePageProps) {
  const furnitureCategories = [
    {
      title: "リビング家具",
      description: "家族みんながくつろげる、お掃除しやすい家具をご紹介。手頃な価格のソファやテーブル、収納家具など、リビングルームを快適にする厳選商品です。月々の負担を抑えた分割払いもご相談できます。",
      image: "https://images.unsplash.com/photo-1708758487256-8a3a73565dc2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxJS0VBJTIwc29mYSUyMGFmZm9yZGFibGUlMjBmdXJuaXR1cmV8ZW58MXx8fHwxNzU3MDUzNzIyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: "¥4,980〜¥39,800",
      amazonUrl: "https://www.amazon.co.jp/s?k=リビング家具+安い&ref=nb_sb_noss"
    },
    {
      title: "キッチン収納",
      description: "料理の時短と整理整頓をサポートする収納家具。食器棚、パントリー収納、調理器具ラックなど、キッチンを効率的に使える手頃な価格の商品です。組み立て簡単で、すぐに使えます。",
      image: "https://images.unsplash.com/photo-1676976500593-3dfec0b17754?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxraXRjaGVuJTIwY2FiaW5ldCUyMHN0b3JhZ2UlMjBvcmdhbml6ZXJ8ZW58MXx8fHwxNzU3MDUzNzI1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: "¥1,980〜¥19,800",
      amazonUrl: "https://www.amazon.co.jp/s?k=キッチン収納+安い&ref=nb_sb_noss"
    },
    {
      title: "子ども部屋家具",
      description: "安全で成長に合わせて使える、親御さん安心の家具。学習デスク、ベッド、おもちゃ収納など、お子様の成長をサポートする手頃な価格の商品です。安全基準をクリアした安心品質です。",
      image: "https://images.unsplash.com/photo-1700050554945-393740dc6a65?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlsZHJlbiUyMGRlc2slMjBzdHVkeSUyMGZ1cm5pdHVyZSUyMGFmZm9yZGFibGV8ZW58MXx8fHwxNzU3MDUzNzI4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: "¥2,980〜¥29,800",
      amazonUrl: "https://www.amazon.co.jp/s?k=子供部屋家具+安い&ref=nb_sb_noss"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-emerald-50">
      {/* ヒーローセクション */}
      <section className="py-16 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold text-slate-800 mb-6">
            家事の負担を減らす家具で<br />
            <span className="text-emerald-600">もっと家族の時間を</span>
          </h2>
          <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto leading-relaxed">
            毎日の家事でお疲れの親御さんへ。掃除しやすく、整理整頓がかんたんで、
            安全性も高い家具をご紹介します。インターネットが苦手でも大丈夫です。
          </p>
          <Button 
            onClick={() => onPageChange("about")}
            className="text-xl px-8 py-4 bg-emerald-600 hover:bg-emerald-700 text-white"
          >
            まずはご相談ください
          </Button>
        </div>
      </section>

      {/* 家具カテゴリー */}
      <section className="py-12 px-4">
        <div className="container mx-auto">
          <h3 className="text-3xl font-bold text-center text-slate-800 mb-12">
            お手伝いできる家具カテゴリー
          </h3>
          
          <div className="grid md:grid-cols-3 gap-8">
            {furnitureCategories.map((category, index) => (
              <Card key={index} className="shadow-lg border-2 border-slate-200 hover:border-emerald-300 transition-colors">
                <CardHeader>
                  <div className="w-full h-48 rounded-lg overflow-hidden mb-4">
                    <ImageWithFallback
                      src={category.image}
                      alt={category.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardTitle className="text-2xl text-slate-800">{category.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* 説明 */}
                  <CardDescription className="text-lg text-slate-600 leading-relaxed">
                    {category.description}
                  </CardDescription>
                  
                  {/* 価格 */}
                  <div className="bg-emerald-50 border-2 border-emerald-200 rounded-lg p-4">
                    <div className="flex items-center space-x-2">
                      <span className="text-emerald-700 font-bold">お手頃価格:</span>
                      <span className="text-2xl font-bold text-emerald-800">{category.price}</span>
                    </div>
                    <p className="text-sm text-emerald-600 mt-1">💝 家計に優しい価格設定です</p>
                    <p className="text-xs text-emerald-500 mt-1">分割払い・配送料無料相談可能</p>
                  </div>
                  
                  {/* Amazonリンクボタン */}
                  <Button
                    onClick={() => window.open(category.amazonUrl, '_blank')}
                    className="w-full text-lg py-3 bg-orange-500 hover:bg-orange-600 text-white"
                  >
                    🛒 Amazonで商品を見る
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* 安心ポイント */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <h3 className="text-3xl font-bold text-center text-slate-800 mb-12">
            「家具のお手伝い」の安心ポイント
          </h3>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center p-6 border-2 border-blue-200">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">📞</span>
              </div>
              <h4 className="text-xl font-bold mb-2">お電話でも対応</h4>
              <p className="text-slate-600">ネットが苦手でも大丈夫。お電話でご相談いただけます</p>
            </Card>

            <Card className="text-center p-6 border-2 border-emerald-200">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🏠</span>
              </div>
              <h4 className="text-xl font-bold mb-2">ご自宅まで配送</h4>
              <p className="text-slate-600">重い家具もご自宅まで安全にお届けします</p>
            </Card>

            <Card className="text-center p-6 border-2 border-teal-200">
              <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">👨‍👩‍👧‍👦</span>
              </div>
              <h4 className="text-xl font-bold mb-2">家族想いの提案</h4>
              <p className="text-slate-600">ご家族の生活スタイルに合った家具をご提案</p>
            </Card>

            <Card className="text-center p-6 border-2 border-slate-300">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">✅</span>
              </div>
              <h4 className="text-xl font-bold mb-2">アフターサポート</h4>
              <p className="text-slate-600">購入後のご不明点もしっかりサポート</p>
            </Card>
          </div>
        </div>
      </section>

      {/* 家計への配慮セクション */}
      <section className="py-16 px-4 bg-gradient-to-r from-emerald-100 to-blue-100">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-slate-800 mb-6">
              家計を考えた、安心価格の家具をご提供
            </h3>
            <p className="text-xl text-slate-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              子育て世代の家計を考え、品質は保ちつつも手頃な価格でご提供。
              毎日忙しい親御さんの負担を、家計面でも軽くします。
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1583558972440-9c263f489656?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZmZvcmRhYmxlJTIwZnVybml0dXJlJTIwZmFtaWx5JTIwYnVkZ2V0fGVufDF8fHx8MTc1NzA1Mzc2NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="家計に優しい家具"
                className="w-full h-80 object-cover rounded-lg shadow-lg"
              />
            </div>
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md border-2 border-emerald-200">
                <h4 className="text-xl font-bold text-emerald-700 mb-3">💰 家計に優しい価格設定</h4>
                <p className="text-slate-600">月々の家計を圧迫しない、お手頃価格でご提供。分割払いもご相談できます。</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md border-2 border-blue-200">
                <h4 className="text-xl font-bold text-blue-700 mb-3">🚚 配送料・組立料も安心</h4>
                <p className="text-slate-600">配送料は可能な限りサービス。組み立てもお手伝いいたします。</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md border-2 border-teal-200">
                <h4 className="text-xl font-bold text-teal-700 mb-3">⭐ 品質は妥協しません</h4>
                <p className="text-slate-600">価格は抑えても、安全性と品質はしっかり確保。長く使える家具をお届けします。</p>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={() => onPageChange("about")}
                className="text-xl px-8 py-4 bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                📞 まずはご相談ください
              </Button>
              <Button 
                onClick={() => onPageChange("game")}
                variant="outline"
                className="text-xl px-8 py-4 border-2 border-teal-600 text-teal-600 hover:bg-teal-50"
              >
                😌 ちょっと息抜きゲーム
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}