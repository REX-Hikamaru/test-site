# 🚀 家具のお手伝い - セットアップガイド

このガイドでは、HTML/CSS/JavaScript/PHP版の「家具のお手伝い」サイトを簡単にセットアップする方法を説明します。

## 📋 必要なもの

### 基本要件
- **Webサーバー**（Apache、Nginx等）
- **PHP 7.4以上**
- **SCSS コンパイル環境**（Node.js推奨）
- **テキストエディタ**（VS Code、Atom、Sublime Text等）

### 推奨環境
- **XAMPP**（Windows）または **MAMP**（Mac）- 開発環境として
- **Git**（バージョン管理用）
- **Google Chrome**（デバッグ用）

## 🔧 Step 1: 基本セットアップ

### 1.1 ファイルのダウンロード・配置

1. **プロジェクトファイルを取得**
   ```bash
   # GitHubからクローンする場合
   git clone [repository-url] kagu-otetsudai
   cd kagu-otetsudai
   
   # または ZIP ダウンロード後解凍
   ```

2. **Webサーバーに配置**
   ```bash
   # XAMPPの場合
   cp -r * /Applications/XAMPP/xamppfiles/htdocs/kagu-otetsudai/
   
   # MAMPの場合
   cp -r * /Applications/MAMP/htdocs/kagu-otetsudai/
   
   # Linuxサーバーの場合
   sudo cp -r * /var/www/html/kagu-otetsudai/
   ```

### 1.2 ディレクトリ権限の設定

```bash
# ログディレクトリを作成
mkdir logs
chmod 755 logs

# PHPファイルの実行権限
chmod 644 *.php
chmod 644 *.html
```

## 🎨 Step 2: SCSS のコンパイル

### 2.1 Node.js環境がある場合（推奨）

```bash
# Sassをグローバルインストール
npm install -g sass

# SCSSファイルをCSSにコンパイル
sass css/style.scss css/style.css

# 監視モード（ファイル変更時に自動コンパイル）
sass css/style.scss css/style.css --watch
```

### 2.2 オンラインコンパイラを使用する場合

1. [Sass Converter](https://jsonformatter.org/scss-to-css) などのオンラインツールを使用
2. `css/style.scss`の内容をコピー＆ペースト
3. コンパイル結果を`css/style.css`として保存

### 2.3 VS Code拡張機能を使用する場合

1. VS Codeで「Live Sass Compiler」拡張機能をインストール
2. SCSSファイルを開いて「Watch Sass」をクリック
3. 自動的にCSSファイルが生成される

## 📧 Step 3: PHPお問い合わせフォーム設定

### 3.1 基本設定の変更

`contact.php`を開いて以下の設定を変更：

```php
$config = [
    'admin_email' => 'your-email@example.com',  // ← あなたのメールアドレスに変更
    'site_name' => '家具のお手伝い',              // ← サイト名（必要に応じて変更）
    'max_message_length' => 2000,
    'allowed_categories' => ['living', 'kitchen', 'children', 'delivery', 'other']
];
```

### 3.2 メール送信のテスト

```php
// contact.php の先頭に以下を追加してテスト
define('DEBUG', true);  // 開発環境でのみtrue
```

### 3.3 エラーログの設定

```bash
# ログファイルの作成
touch logs/contact.log
chmod 666 logs/contact.log
```

## 🌐 Step 4: Webサーバーの起動

### 4.1 XAMPP使用時

1. XAMPPコントロールパネルを起動
2. Apache と MySQL を Start
3. ブラウザで `http://localhost/kagu-otetsudai/` にアクセス

### 4.2 MAMP使用時

1. MAMPを起動
2. 「Start Servers」をクリック
3. ブラウザで `http://localhost:8888/kagu-otetsudai/` にアクセス

### 4.3 PHP内蔵サーバー使用時

```bash
# プロジェクトディレクトリで実行
php -S localhost:8000

# ブラウザで http://localhost:8000 にアクセス
```

## ✅ Step 5: 動作確認

### 5.1 基本表示の確認

- [ ] サイトが正常に表示される
- [ ] ナビゲーションボタンが動作する
- [ ] 3つのページが切り替わる
- [ ] 画像が正常に読み込まれる

### 5.2 お問い合わせフォームの確認

- [ ] フォームが表示される
- [ ] 必須項目のバリデーションが動作する
- [ ] 送信後にメッセージが表示される
- [ ] 管理者メールが届く（メール設定済みの場合）

### 5.3 ミニゲームの確認

- [ ] 深呼吸ゲームが動作する
- [ ] 記憶ゲームが動作する
- [ ] 数字パズルが動作する

## 🎯 Step 6: カスタマイズ

### 6.1 会社情報の変更

`index.html`を編集して以下を変更：

1. **会社名**
```html
<h1>家具のお手伝い</h1>  <!-- ← ここを変更 -->
```

2. **電話番号**
```html
<span>0120-123-456</span>  <!-- ← ここを変更 -->
```

3. **住所**
```html
<span>東京都世田谷区桜新町1-2-3</span>  <!-- ← ここを変更 -->
```

4. **メールアドレス**
```html
<span>info@kagu-otetsudai.jp</span>  <!-- ← ここを変更 -->
```

### 6.2 価格の変更

家具カテゴリーの価格を変更：

```html
<div class="price">¥4,980〜¥39,800</div>  <!-- ← ここを変更 -->
```

### 6.3 商品説明の変更

各カテゴリーの説明文を編集：

```html
<p class="category-description">
    家族みんながくつろげる、お掃除しやすい家具をご紹介...  <!-- ← ここを変更 -->
</p>
```

## 🔧 Step 7: 本番環境への配置

### 7.1 本番用設定

1. **PHP設定の変更**
```php
// contact.php
// define('DEBUG', true);  // ← コメントアウト
error_reporting(E_ALL);
ini_set('display_errors', 0);  // 本番では0
```

2. **セキュリティ設定**
```php
// CSRFトークンの有効化
if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
    throw new Exception('セキュリティトークンが無効です。');
}
```

### 7.2 ファイルアップロード

FTPクライアント（FileZilla等）を使用してサーバーにアップロード：

```
/public_html/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
├── contact.php
└── logs/ (権限755)
```

### 7.3 SSL証明書の設定

多くのホスティングサービスで無料SSL（Let's Encrypt）が利用可能です。

## 🚨 トラブルシューティング

### よくある問題と解決方法

**Q1: サイトが表示されない**
```
A: 以下を確認してください
- Webサーバーが起動しているか
- ファイルパスが正しいか
- PHPが有効になっているか
```

**Q2: スタイルが適用されない**
```
A: 以下を確認してください
- SCSSがCSSにコンパイルされているか
- style.cssファイルが存在するか
- ブラウザキャッシュをクリアする
```

**Q3: お問い合わせフォームが動かない**
```
A: 以下を確認してください
- PHPのエラーログをチェック
- メール設定が正しいか
- ログディレクトリの権限が正しいか
```

**Q4: JavaScriptが動かない**
```
A: 以下を確認してください
- ブラウザの開発者ツールでエラーをチェック
- script.jsファイルが正しく読み込まれているか
- 古いブラウザの場合はポリフィルが必要か
```

## 📱 Step 8: レスポンシブ対応確認

### デバイス別確認

1. **デスクトップ** (1200px以上)
   - [ ] 3カラムレイアウトが正常
   - [ ] ナビゲーションが横並び

2. **タブレット** (768px-1199px)
   - [ ] 2カラムレイアウトに変更
   - [ ] 画像サイズが適切

3. **スマートフォン** (767px以下)
   - [ ] 1カラムレイアウト
   - [ ] ボタンが指で押しやすいサイズ
   - [ ] フォントサイズが読みやすい

## 🔒 Step 9: セキュリティチェック

### 基本セキュリティ確認

- [ ] PHPエラー表示が無効になっている（本番環境）
- [ ] 管理者メールアドレスが設定済み
- [ ] ログファイルがWeb経由でアクセスできない場所にある
- [ ] フォームのバリデーションが正常に動作する
- [ ] XSS対策が実装されている

## 🎉 完了！

以上でセットアップは完了です。

### 次のステップ

1. **Google Analytics の設定** - アクセス解析のため
2. **SEO対策** - meta description, keywords の設定
3. **定期メンテナンス** - ログファイルの確認、セキュリティアップデート

### サポート

セットアップでご不明な点がございましたら、以下のリソースをご活用ください：

- 📚 **詳細ドキュメント**: `README_VANILLA.md`
- 🔧 **カスタマイズガイド**: HTMLファイル内のコメント
- 💡 **よくある質問**: このガイドのトラブルシューティングセクション

**家具のお手伝いサイトの構築、お疲れ様でした！** 👏